document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    
    if (username === 'admin' && password === 'admin@24') {
        window.location.href = 'dashboard.html';
    } else {
        alert('Invalid username or password');
    }
});
